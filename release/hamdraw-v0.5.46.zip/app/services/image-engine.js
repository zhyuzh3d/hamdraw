(function (app) {
  "use strict";
  var timer = 0, running = false, queuedSlot = "", generation = 0, dismissed = false;
  var canvasInput = null;
  var t = app.i18n.text;
  // Rendering is not a fresh painting. It enlarges the picture already on the
  // canvas and repairs its detail, so the reference image is what carries the
  // content and the prompt only says how to treat it. The artwork description
  // follows as a hint at what the model is looking at, never as an instruction to
  // paint that description again; the render negatives push the same way.
  var RENDER_PROMPT = "high resolution upscale of this exact image, keep composition, colors and every element identical, repair detail only, no repaint";
  var RENDER_NEGATIVE = "repaint, redrawn, changed composition, different framing, extra elements, missing elements, restyled, altered colors";
  function configured(slot) {
    var config = app.config && app.config[slot];
    return Boolean(config && config.endpoint);
  }
  function schedule() {
    clearTimeout(timer);
    if (app.state.maskMode || !app.state.autoGenerate || !configured("quick")) return;
    timer = setTimeout(function () { run("quick", true); }, Number(app.state.autoDelayMs) || 850);
  }
  function stopAuto() { clearTimeout(timer); queuedSlot = ""; }
  function cancel() {
    clearTimeout(timer); generation += 1; queuedSlot = ""; dismissed = true; running = false; app.state.busy = false;
    app.events.emit("generation:idle");
  }
  function withDeadline(promise, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timerId = setTimeout(function () {
        if (settled) return;
        settled = true;
        reject(new Error(t("生成等待超时，已结束本次等待；服务端任务可能仍在运行，请稍后重试", "Generation timed out and this wait was closed. The server job may still be running; try again shortly.")));
      }, timeoutMs);
      promise.then(function (value) {
        if (settled) return;
        settled = true; clearTimeout(timerId); resolve(value);
      }, function (error) {
        if (settled) return;
        settled = true; clearTimeout(timerId); reject(error);
      });
    });
  }
  function overallTimeout(config) {
    var configured = Number(config && config.timeoutMs) || 90000;
    return Math.max(15000, Math.min(330000, configured + 15000));
  }
  async function run(requested, automatic) {
    clearTimeout(timer);
    var masking = Boolean(app.state.maskMode) && canvasInput.hasMask();
    // A masked canvas always means "local redraw"; the quick button becomes the
    // local-redraw button while the mask tool is open.
    var slot = masking && (requested === "quick" || !requested) ? "inpaint" : requested === "quality" ? "upscale" : requested;
    if (["quick", "inpaint", "upscale"].indexOf(slot) < 0) slot = "quick";
    if (running) {
      queuedSlot = slot;
      app.events.emit("status", t("最新画面已排队，当前请求完成后继续", "Latest sketch queued until the current request finishes"));
      return;
    }
    if (!configured(slot)) {
      if (!automatic) app.events.emit("needs-config", slot);
      return;
    }
    // A local redraw states what the marked area should become. Submitting the
    // artwork-wide prompt as well would drag the whole composition into the
    // patched region, so only the local description travels with the mask.
    // A render leads with the fidelity instruction, so the artwork description can
    // never read as "paint this picture again", and it no longer needs one at all.
    //
    // What leaves is the prompt exactly as it was written. Deciding whether a
    // model can read it is no longer this side's business: the CHP plugin owns
    // the translator and its memory, translates on submit when a text encoder
    // needs English, and reports back through `translated` / `prompt` /
    // `prompt_source` what it did. Translating here as well would be a second
    // mechanism for the same fact, and two of those disagree eventually.
    var prompt = masking ? app.utils.composePrompt("", app.state.localPrompt)
      : slot === "upscale" ? app.utils.composePrompt(RENDER_PROMPT, app.state.prompt)
      : app.utils.composePrompt(app.state.prompt, "");
    var negativePrompt = slot === "upscale" ? app.utils.composePrompt(RENDER_NEGATIVE, app.state.negativePrompt) : app.state.negativePrompt;
    var config = app.utils.copy(app.config[slot]);
    // Only the slot: the category a CHP task submits is resolved from it through
    // the one map in services/providers.js, so no second name for the same task
    // travels with a request.
    config.slot = slot;
    if (slot === "upscale") config.inputMode = "sketch";
    if (masking && !String(app.state.localPrompt || "").trim()) {
      if (!automatic) app.events.emit("error", new Error(t("先点「描述」写清这一块要改成什么，再生成", "Describe what this area should become first")));
      return;
    }
    if (!prompt) {
      if (!automatic) app.events.emit("error", new Error(t("先在画布上方描述你想画什么", "Describe your idea above the canvas first")));
      return;
    }
    if (masking && (requested === "upscale" || requested === "quality")) {
      if (!automatic) app.events.emit("error", new Error(t("局部模式下请点生成按钮重绘蒙版区域；要渲染大图请先关闭局部工具", "In mask mode use Generate to repaint the masked area. Close the mask tool first to render a large image.")));
      return;
    }
    if (masking && config.inputMode === "text") {
      if (!automatic) app.events.emit("error", new Error(t("当前模型是纯文字模式，不支持局部蒙版", "This model is prompt-only and cannot use a mask")));
      return;
    }
    if (masking && ["openai-images", "sd-webui", "chp"].indexOf(config.protocol) < 0) {
      if (!automatic) app.events.emit("error", new Error(t("当前模型不支持局部蒙版，请使用 CHP 插件、OpenAI Images 或 SD WebUI", "Masks need the CHP plugin, OpenAI Images, or SD WebUI")));
      return;
    }
    running = true; queuedSlot = ""; dismissed = false;
    var token = ++generation;
    var succeeded = false;
    app.state.busy = true; app.events.emit("generation:start", { slot: slot });
    try {
      var maskDataUrl = null, openAiMaskDataUrl = null;
      //: Every slot composes its reference at the canvas the job actually runs at,
      //: not at the app's own 768² drawing surface. The plugin scales whatever
      //: reference it is handed to exactly the job canvas before it encodes it, so
      //: a 768² reference buys a resample rather than detail: the same picture
      //: reaches the model either way, through one more conversion and a body
      //: roughly half again as large. The mask is composed at that same size, so
      //: the two arrive on the grid the sampler uses.
      var jobSize = Number(config.width) || (slot === "upscale" ? 1024 : 512);
      if (masking) {
        if (config.protocol === "openai-images") openAiMaskDataUrl = canvasInput.composeMask(true, jobSize);
        else if (config.protocol === "sd-webui" || config.protocol === "chp") maskDataUrl = canvasInput.composeMask(false, jobSize);
      }
      // The reference image is encoded as a JPEG rather than a PNG because a
      // full-size PNG would not fit, but it no longer has to pay for the mask:
      // a body that outgrows one bridge message is filed in the host file store,
      // so the mask is no longer subtracted from what the reference may weigh.
      // A local redraw has to reference the decorated result instead of the
      // sketch, and says so explicitly rather than relying on the mask mode flag
      // alone.
      var referenceOptions = {
        mime: "image/jpeg",
        quality: 0.92,
        maxBytes: app.platform.haminn.messageChars || 200000,
        size: jobSize
      };
      if (masking) referenceOptions.withResult = true;
      var input = { prompt: prompt, negativePrompt: negativePrompt, seed: app.state.seedLocked ? app.state.seed : -1, strength: app.state.strength, colorStrength: app.state.colorStrength,
        imageDataUrl: slot === "upscale" ? await canvasInput.composeVisibleInput(referenceOptions) : await canvasInput.composeInput(referenceOptions),
        maskDataUrl: maskDataUrl, openAiMaskDataUrl: openAiMaskDataUrl };
      var result = await withDeadline(app.services.providers.generate(config, input), overallTimeout(config));
      if (token !== generation) return;
      if (slot === "upscale") {
        var dimensions = await canvasInput.imageDimensions(result.src);
        var wantWidth = Number(config.width) || 1024, wantHeight = Number(config.height) || 1024;
        if (dimensions.width !== wantWidth || dimensions.height !== wantHeight) throw new Error(t("渲染接口返回了 " + dimensions.width + " × " + dimensions.height + "，需要 " + wantWidth + " × " + wantHeight, "The render API returned " + dimensions.width + " × " + dimensions.height + "; " + wantWidth + " × " + wantHeight + " is required"));
      }
      var generated = { src: result.src, logicalFileId: result.logicalFileId || "", slot: slot, prompt: prompt, createdAt: Date.now() };
      if (slot === "upscale") app.state.renderResult = generated; else app.state.result = generated;
      succeeded = true;
      app.events.emit("generation:done", generated);
      // The picture goes into Haminn's file store the moment it arrives, not on the next
      // autosave, and that reference becomes this document's cover: the card keeps showing
      // the newest generation even if the app is closed right after it. The cover shares
      // the result's reference — one picture, filed once — and a filing that fails leaves
      // the previous cover in place rather than pointing the card at files that are gone.
      app.state.cover = (await app.services.assets.coverFrom(generated)) || app.state.cover;
      if (slot !== "upscale") app.services.store.scheduleCanvasSave();
    } catch (error) {
      if (token === generation) app.events.emit("generation:error", error);
    } finally {
      if (token !== generation) return;
      running = false; app.state.busy = false;
      if (!dismissed) app.events.emit("generation:idle");
      var next = succeeded ? queuedSlot : ""; queuedSlot = "";
      if (next) setTimeout(function () { run(next, true); }, 60);
    }
  }
  app.services.imageEngine = { init: function (input) { canvasInput = input; }, schedule: schedule, run: run, configured: configured, cancel: cancel, stopAuto: stopAuto,
    internals: { withDeadline: withDeadline, overallTimeout: overallTimeout } };
})(window.hamdraw);
