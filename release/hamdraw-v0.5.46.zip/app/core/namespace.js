(function (global) {
  "use strict";

  var app = global.hamdraw = global.hamdraw || {};
  var listeners = {};

  app.version = "0.5.46";
  app.events = {
    on: function (name, listener) {
      listeners[name] = listeners[name] || [];
      listeners[name].push(listener);
      return function () {
        listeners[name] = (listeners[name] || []).filter(function (item) { return item !== listener; });
      };
    },
    emit: function (name, detail) {
      (listeners[name] || []).slice().forEach(function (listener) {
        try { listener(detail); } catch (error) { setTimeout(function () { throw error; }, 0); }
      });
    }
  };

  app.state = {
    tool: "pencil",
    color: "#38a9e8",
    background: "#ffffff",
    size: 18,
    opacity: 0.72,
    resultOpacity: 0.9,
    layerOpacity: 1,
    resultVisible: true,
    maskVisible: true,
    resultBrightness: 100,
    resultContrast: 100,
    resultSaturation: 100,
    resultHue: 0,
    resultGlow: 0,
    resultClarity: 0,
    resultAdjustmentsEnabled: true,
    workId: "",
    workTitle: "",
    prompt: "",
    negativePrompt: "",
    seed: Math.floor(Math.random() * 2147483647),
    seedLocked: true,
    strength: 0.8,
    colorStrength: 0.3,
    autoDelayMs: 850,
    autoGenerate: true,
    overlayGenerate: false,
    selectedId: "",
    selectedIds: [],
    objects: [],
    // The containers a drawing is holding: one entry per group, carrying the group's own placement
    // and the rectangle it is. The members only name one, which is what lets a group be transformed
    // - and gives a group a rectangle of its own to be selected and resized by.
    groups: {},
    result: null,
    renderResult: null,
    // The cover is the last generated picture, kept as a reference into Haminn's file
    // store. It outlives the result it came from, so a history card keeps showing the
    // newest generation even after the sketch or the result is cleared.
    cover: null,
    busy: false,
    history: [],
    future: []
  };

  app.defaults = {
    schema: 10,
    preferences: { theme: "system", language: "zh" },
    // One ComfyUI plugin serves all three tasks, so they share one connection:
    // address, password and custom headers live here and are copied into every CHP
    // task on load and on save. Selecting CHP in another task adopts this; editing it
    // anywhere edits all three. The task-specific settings stay per task.
    connection: { endpoint: "", apiKey: "", customHeaders: "" },
    quick: {
      slot: "quick",
      name: "快速生图",
      protocol: "chp",
      endpoint: "",
      apiKey: "",
      model: "",
      inputMode: "sketch",
      width: 512,
      height: 512,
      steps: 8,
      refStrength: 0.55,
      quality: "low",
      timeoutMs: 60000,
      customHeaders: "",
      workflow: "",
      guidanceScale: 2
    },
    inpaint: {
      slot: "inpaint",
      name: "局部重绘",
      protocol: "chp",
      endpoint: "",
      apiKey: "",
      model: "",
      inputMode: "sketch",
      width: 512,
      height: 512,
      steps: 6,
      refStrength: 0.3,
      quality: "low",
      timeoutMs: 90000,
      customHeaders: "",
      workflow: "",
      guidanceScale: 2
    },
    upscale: {
      slot: "upscale",
      name: "高清渲染",
      protocol: "chp",
      endpoint: "",
      apiKey: "",
      model: "",
      inputMode: "sketch",
      width: 1024,
      height: 1024,
      // The canvas and the reference weight below belong to the category this task
      // submits — `upscale`, the same word this slot uses. They are only the starting
      // point: once the plugin's information document has been read, the canvas comes
      // from the frame it publishes and the weight from its own defaults, and the
      // sheet prints them rather than offering them.
      steps: 8,
      refStrength: 0.75,
      quality: "high",
      timeoutMs: 240000,
      customHeaders: "",
      workflow: "",
      guidanceScale: 1
    },
    canvas: {
      negativePrompt: "low quality, distorted, unfinished, artifacts",
      autoDelayMs: 850,
      resultBrightness: 100,
      resultContrast: 100,
      resultSaturation: 100,
      resultHue: 0,
      resultGlow: 0,
      resultClarity: 0,
      resultAdjustmentsEnabled: true
    }
  };

  app.config = null;
  app.platform = {};
  app.services = {};
  app.components = {};
  app.features = {};
})(window);
